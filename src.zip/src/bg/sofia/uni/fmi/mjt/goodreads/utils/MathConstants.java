package bg.sofia.uni.fmi.mjt.goodreads.utils;

public class MathConstants {
    public static final double DELTA = 0.0001;
}
